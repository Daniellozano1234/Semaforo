<template>
  <div>
    <TrafficLight />
  </div>
</template>

<script setup>
import TrafficLight from '~/components/TrafficLight.vue';
</script>

<style scoped>
body {
  margin: 0;
  padding: 0;
  font-family: Arial, sans-serif;
}
</style>
