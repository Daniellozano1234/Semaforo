<template>
    <div class="traffic-light-container">
      <h1 class="title">Semáforo</h1>
      <div class="traffic-light">
        <div class="light-container">
          <RedLight :isActive="activeRed" />
          <YellowLight :isActive="activeYellow" />
          <GreenLight :isActive="activeGreen" />
        </div>
        <div class="buttons-container">
          <button @click="setActive('red')">Activar Rojo</button>
          <button @click="setActive('yellow')">Activar Amarillo</button>
          <button @click="setActive('green')">Activar Verde</button>
        </div>
      </div>
    </div>
  </template>
  
  <script setup>
  import { ref } from 'vue';
  import RedLight from '~/components/RedLight.vue';
  import YellowLight from '~/components/YellowLight.vue';
  import GreenLight from '~/components/GreenLight.vue';
  
  const activeRed = ref(false);
  const activeYellow = ref(false);
  const activeGreen = ref(false);
  
  const setActive = (color) => {
    // Desactivamos todas las luces
    activeRed.value = false;
    activeYellow.value = false;
    activeGreen.value = false;
  
    // Activamos la luz correspondiente
    if (color === 'red') {
      activeRed.value = true;
    } else if (color === 'yellow') {
      activeYellow.value = true;
    } else if (color === 'green') {
      activeGreen.value = true;
    }
  };
  </script>
  
  <style scoped>
  .traffic-light-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100vh;
    background-color: #007bff; /* Fondo azul */
  }
  
  .title {
    font-size: 2rem;
    color: white;
    margin-bottom: 20px;
  }
  
  .traffic-light {
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: #222;
    border-radius: 10px;
    padding: 20px;
  }
  
  .light-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-right: 20px; /* Espacio entre luces y botones */
  }
  
  .buttons-container {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
  }
  
  button {
    cursor: pointer;
    padding: 10px 15px;
    background-color: #fff;
    color: #007bff;
    border: 2px solid #007bff;
    border-radius: 5px;
    margin: 10px;
  }
  
  button:hover {
    background-color: #007bff;
    color: white;
  }
  </style>
  