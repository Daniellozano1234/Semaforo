<template>
    <div class="light">
      <div class="color green" :class="{ active: isActive }"></div>
    </div>
  </template>
  
  <script setup>
  const props = defineProps({
    isActive: Boolean
  });
  </script>
  
  <style scoped>
  .light {
    display: flex;
    flex-direction: column;
    align-items: center;
  }
  
  .color {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    margin-bottom: 10px;
    opacity: 0.3;
    transition: opacity 0.3s ease-in-out;
  }
  
  .green {
    background-color: green;
  }
  
  .active {
    opacity: 1;
  }
  </style>
  